### Name: spay-class
### Title: Class "spay" for standardised proportion at age per year
### Aliases: spay-class spay spay-methods spay,FLQuant-method
### Keywords: classes

### ** Examples

data(ple4sex)
# compute standardized catch proportion at age
ple4sex.spay <- spay(ple4sex@catch.n)
# fine tune 
ttl <- list(label="Standardized catch proportion at age for Plaice in IV", cex=1)
yttl <- list(label="age", cex=0.8)
xttl <- list(cex=0.8)
ax <- list(cex=0.7)
# plot
bubbles(age~year|unit, ple4sex.spay,  main=ttl, 
        ylab=yttl, xlab=xttl, scales=ax)



