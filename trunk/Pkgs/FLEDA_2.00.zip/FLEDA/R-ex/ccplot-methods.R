### Name: ccplot-methods
### Title: Catch curves plot method
### Aliases: ccplot-methods ccplot ccplot,formula,FLCohort-method
### Keywords: methods

### ** Examples

# not ready yet !



