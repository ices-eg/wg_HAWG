### Name: fwdControl
### Title: Controls for fwd
### Aliases: fwdControl
### Keywords: fwd fwdControl

### ** Examples

## Not run: Control<-fwdControl(list(year    =rep(1995:2000),value=c(.40,100000,5000,120000,220000,0.65),
##D                        quantity=c("f", "ssb","catch","ssb","ssb","f")))
##D 
## End(Not run)


