### Name: logcc-class
### Title: Class "logcc" for log catch curves
### Aliases: logcc-class logcc logcc-methods logcc,FLQuant-method
### Keywords: classes

### ** Examples

data(ple4sex)
# compute logcc
ple4sex.cc <- logcc(ple4sex@catch.n)
# fine tune plot
ttl <- list(label="Log catch curves by sex for plaice in IV", cex=1)
yttl <- list(label="log ratio", cex=0.8)
xttl <- list(cex=0.8)
stripttl <- list(cex=0.8)
ax <- list(cex=0.7)
# plot
ccplot(data~age|unit, data=ple4sex.cc, type="l", main=ttl, 
       ylab=yttl, xlab=xttl, scales=ax, par.strip.text=stripttl, col=1)



