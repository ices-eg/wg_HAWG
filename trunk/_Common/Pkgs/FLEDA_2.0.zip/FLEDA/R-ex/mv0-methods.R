### Name: mv0-methods
### Title: Compute missing values and 0
### Aliases: mv0-methods mv0 mv0,FLQuant-method mv0,FLQuants-method
### Keywords: methods

### ** Examples

data(ple4.index)
mv0(index(ple4.index))



