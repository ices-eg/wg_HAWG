### R code from vignette source 'FLSAM.Rnw'

###################################################
### code chunk number 1: FLSAM.Rnw:27-28 (eval = FALSE)
###################################################
## install.packages("<pathToFLSAM>/<FLSAM file>")


###################################################
### code chunk number 2: FLSAM.Rnw:40-41 (eval = FALSE)
###################################################
## install.packages("FLCore", repos="http://flr-project.org/R")


###################################################
### code chunk number 3: FLSAM.Rnw:48-49
###################################################
library(FLCore)


###################################################
### code chunk number 4: FLSAM.Rnw:59-60 (eval = FALSE)
###################################################
## stck <- readFLStock(file.path(".","data","index.txt"),no.discards=TRUE)


###################################################
### code chunk number 5: FLSAM.Rnw:65-66 (eval = FALSE)
###################################################
## tun <- readFLIndices(file.path(".","data","fleet.txt"))


###################################################
### code chunk number 6: FLSAM.Rnw:70-72 (eval = FALSE)
###################################################
##  summary(stck)
##  summary(tun)


###################################################
### code chunk number 7: FLSAM.Rnw:77-81
###################################################
 library(FLSAM)
 data(NSH)
 stck <- NSH
 tun  <- NSH.tun


###################################################
### code chunk number 8: FLSAM.Rnw:89-90
###################################################
ctrl <- FLSAM.control(stck,tun)


###################################################
### code chunk number 9: FLSAM.Rnw:94-95
###################################################
ctrl@catchabilities["HERAS","8"] <- 12


###################################################
### code chunk number 10: FLSAM.Rnw:99-101
###################################################
 data(NSH.sam)
 ctrl <- NSH.ctrl


###################################################
### code chunk number 11: FLSAM.Rnw:109-110 (eval = FALSE)
###################################################
##  sam <- FLSAM(stck,tun,ctrl)


###################################################
### code chunk number 12: FLSAM.Rnw:113-114
###################################################
sam <- NSH.sam


###################################################
### code chunk number 13: FLSAM.Rnw:120-121
###################################################
new_stck <- stck + sam


###################################################
### code chunk number 14: FLSAM.Rnw:129-130 (eval = FALSE)
###################################################
## plot(sam)


###################################################
### code chunk number 15: stocksumplot
###################################################
print(plot(sam))


###################################################
### code chunk number 16: stocksumfig
###################################################
print(plot(sam))


###################################################
### code chunk number 17: residsplot
###################################################
residual.diagnostics(sam)


###################################################
### code chunk number 18: residsfig
###################################################
residual.diagnostics(sam)


###################################################
### code chunk number 19: FLSAM.Rnw:168-170 (eval = FALSE)
###################################################
## par(ask=TRUE) 
## residual.diagnostics(sam)


###################################################
### code chunk number 20: FLSAM.Rnw:173-176 (eval = FALSE)
###################################################
## pdf("Diagnostics.pdf")
## residual.diagnostics(sam)
## dev.off()


###################################################
### code chunk number 21: obsvarplot
###################################################
obsvar.plot(sam)


###################################################
### code chunk number 22: obsvarfig
###################################################
obsvar.plot(sam)


###################################################
### code chunk number 23: otoplot
###################################################
otolith(sam,year=2011,plot=T,n=1000)


###################################################
### code chunk number 24: otofig
###################################################
otolith(sam,year=2011,plot=T,n=1000)


###################################################
### code chunk number 25: FLSAM.Rnw:209-210 (eval = FALSE)
###################################################
## otolith(sam,year=2011,plot=T,n=1e5)


###################################################
### code chunk number 26: corplot
###################################################
cor.plot(sam)


###################################################
### code chunk number 27: corfig
###################################################
cor.plot(sam)


###################################################
### code chunk number 28: FLSAM.Rnw:230-232 (eval = FALSE)
###################################################
## retro.sams <- retro(stck,tun,ctrl,retro=5)
## plot(retro.sams)


###################################################
### code chunk number 29: retrofig
###################################################
if(!exists("retro.sams")) {
  retro.sams <- retro(stck,tun,ctrl,retro=5)}
plot(retro.sams)


###################################################
### code chunk number 30: FLSAM.Rnw:248-250 (eval = FALSE)
###################################################
## loo.sams <- loo(stck,tun,ctrl)
## plot(retro.sams)


###################################################
### code chunk number 31: loofig
###################################################
if(!exists("loo.sams")) {
  loo.sams <- loo(stck,tun,ctrl)}
plot(loo.sams)


###################################################
### code chunk number 32: FLSAM.Rnw:267-270
###################################################
sam@control@sam.binary  <- character()
sam.out <- FLSAM.out(stck,tun,sam,
                format="Table 1.%i North Sea herring assessment")


###################################################
### code chunk number 33: FLSAM.Rnw:273-274
###################################################
sam.out[1:10]


###################################################
### code chunk number 34: FLSAM.Rnw:277-279 (eval = FALSE)
###################################################
## options("width"=80,"scipen"=1000)
## write(sam.out,file="sam.out")


###################################################
### code chunk number 35: qplot
###################################################
plot.dat <- catchabilities(sam)
library(lattice)
print(xyplot(value+ubnd+lbnd ~ age | fleet, 
          data=plot.dat,subset=fleet %in% c("HERAS"),
          scale=list(alternating=FALSE,y=list(relation="free")),as.table=TRUE,
          type="l",lwd=c(2,1,1),col=c("black","grey","grey"),
          main="HERAS catchability parameters",
          ylab="Catchability",xlab="Age",ylim=c(0,2)))


###################################################
### code chunk number 36: qfig
###################################################
plot.dat <- catchabilities(sam)
library(lattice)
print(xyplot(value+ubnd+lbnd ~ age | fleet, 
          data=plot.dat,subset=fleet %in% c("HERAS"),
          scale=list(alternating=FALSE,y=list(relation="free")),as.table=TRUE,
          type="l",lwd=c(2,1,1),col=c("black","grey","grey"),
          main="HERAS catchability parameters",
          ylab="Catchability",xlab="Age",ylim=c(0,2)))


