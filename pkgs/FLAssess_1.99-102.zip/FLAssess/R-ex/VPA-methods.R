### Name: VPA-methods
### Title: Virtual Population Analysis in FLR
### Aliases: VPA VPA-methods VPA,FLStock-method FLVPA-class
### Keywords: methods models

### ** Examples

# use the ple4 data set
data(ple4)
ple4.test <- ple4
# Remove 0s and set as 1s
catch.n(ple4.test)[catch.n(ple4.test)==0] <- 1
# Catch is odd in 1982 in pg; it's huge compared to biomass.
# This causes VPA to fail so need to reduce
catch.n(ple4.test)[,"1982"] <- 1400
# Remove harvest and stock.n values
stock.n(ple4.test)[] <- NA
harvest(ple4.test)[] <- NA
# Set Fs in final year and final ages
harvest(ple4.test)[,"2001"] <- harvest(ple4)[,"2001"]
harvest(ple4.test)[15,] <- harvest(ple4)[15,]
# Run the VPA
ple4.vpa <- VPA(ple4.test)



