### Name: as.data.frame-method
### Title: Correlation for class "FLQuant"
### Aliases: cor-method cor,FLQuant,ANY-method cor,FLQuant,FLQuant-method
### Keywords: methods

### ** Examples

data(ple4)
c1 <- cor(catch.n(ple4), use="complete.obs", method="spearman")
round(c1,2)
c2 <- cor(catch.n(ple4), use="all.obs", method="spearman")
round(c2,2)
all.equal(c1,c2)



