### Name: z-class
### Title: Class "z" for total mortality
### Aliases: z-class z z-methods z,FLQuant-method summary,z-method
###   t.test,z-method
### Keywords: classes

### ** Examples

data(ple4)
# compute Z
ple4z <- z(catch.n(ple4), agerng=3:6)
# tune plot
ttl <- list("Total mortality (Z) for Plaice in IV", cex=1)
xttl <- list(cex=0.8)
yttl <- list("Mean Z", cex=0.8)
# plot z by age along years
xyplot(data~year, data=ple4z@zy, type="l", main=ttl, ylab=yttl, xlab=xttl)
# plot z by age along ages
xyplot(data~age, data=ple4z@za, type="l", main=ttl, ylab=yttl, xlab=xttl)
# plot z by cohort along years
xyplot(data~cohort, data=ple4z@zc, type="l", main=ttl, ylab=yttl, xlab=xttl)



