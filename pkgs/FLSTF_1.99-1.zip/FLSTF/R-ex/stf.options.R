### Name: stf.options
### Title: ICES style management options table
### Aliases: stf.options
### Keywords: classes

### ** Examples


library(FLSTF)
data(ple4)

ple4.stf  <- FLSTF(ple4, FLSTF.control())
stf.options(ple4.stf)




