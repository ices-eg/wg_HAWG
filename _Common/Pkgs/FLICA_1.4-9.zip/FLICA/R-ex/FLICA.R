### Name: FLICA
### Title: Stock Assessment using Integrated Catch-at-Age Analysis (ICA)
### Aliases: FLICA
### Keywords: classes

### ** Examples


   #Load assessment objects
   data(herIIIa)
   data(herIIIa.tun)
   data(herIIIa.ctrl)
   #Perform assessment
   herIIIa.ica  <- FLICA(herIIIa, herIIIa.tun, herIIIa.ctrl)
   herIIIa <- herIIIa + herIIIa.ica
   #Show the results
   summary(herIIIa)
   herIIIa@stock.n
   herIIIa@harvest



