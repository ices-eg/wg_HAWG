### Name: FLICA.control
### Title: Create a new FLICA.control object
### Aliases: FLICA.control
### Keywords: classes

### ** Examples

        # To create a new FLICA.control object with default parameters:



