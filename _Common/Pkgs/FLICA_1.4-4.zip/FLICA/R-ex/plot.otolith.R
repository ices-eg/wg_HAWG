### Name: plot.otolith
### Title: Visualise uncertainity in the terminal Fbar and SSB
### Aliases: plot.otolith plot.banana
### Keywords: classes

### ** Examples

   #Load assessment objects
   data(herIIIa)
   data(herIIIa.tun)
   data(herIIIa.ctrl)
   #Perform assessment
   herIIIa.ica  <- FLICA(herIIIa, herIIIa.tun, herIIIa.ctrl)
   herIIIa <- herIIIa + herIIIa.ica
   #Plot otolith
   plot.otolith(herIIIa, herIIIa.ica)
   #Plot banana
   plot.banana(herIIIa, herIIIa.ica)

   #Compare the results of two assessment settings using otoliths
   herIIIa.ctrl@sep.age <- as.integer(6)                #Normally 4 in this assessment
   herIIIa.age6.ica  <- FLICA(herIIIa, herIIIa.tun, herIIIa.ctrl)
   herIIIa.age6      <- herIIIa + herIIIa.age6.ica
   #Now make the otolith plots
   plot.otolith(herIIIa, herIIIa.ica)
   age6.otolith <- plot.otolith(herIIIa.age6, herIIIa.age6.ica,plot=FALSE)
   age6.otolith$col  <- "red"
   age6.otolith$lwd  <- 2
   do.call(contour,age6.otolith)
   #Add the estimate via this method    
   points(fbar(herIIIa.age6)[,"2007"],ssb(herIIIa.age6)[,"2007"],col="red",pch=18,cex=2)
   #Finally, add a legend in the upper right
   plot.new()
   legend("topright",legend=c("Age 4","Age 6"),pch=c(19,18),col=c("black","red"),lwd=c(1,2))



