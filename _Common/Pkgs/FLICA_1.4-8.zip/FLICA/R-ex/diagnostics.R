### Name: diagnostics
### Title: FLICA assessment diagnostics
### Aliases: diagnostics
### Keywords: classes

### ** Examples

   #Load assessment objects
   data(herIIIa)
   data(herIIIa.tun)
   data(herIIIa.ctrl)
   #Perform assessment
   herIIIa.ica  <- FLICA(herIIIa, herIIIa.tun, herIIIa.ctrl)

   #Generate diagnostics with clicking between each graph
   par(ask=TRUE)
   diagnostics(herIIIa.ica)
   diagnostics(herIIIa.ica,type="all.catch")
   diagnostics(herIIIa.ica,show.index="N20",type="normal.index")
   #Only show the catch selectivity plot on one figure
   diagnostics(herIIIa.ica,main.title=FALSE, plot.titles=FALSE, type="selectivity",par.settings=list(mfrow=c(1,1)))
   #Only show the qq-plot for the Ger AS 1-3 index at age 1
   diagnostics(herIIIa.ica,main.title=FALSE, plot.titles=FALSE, show.index="Ger AS 1-3 wr",show.age="1",type="qq",par.settings=list(mfrow=c(1,1)))
   #Write all figures to png files for adding to a report.
   png("herIIIa diagnostics - 
   diagnostics(herIIIa.ica)
   dev.off()   



