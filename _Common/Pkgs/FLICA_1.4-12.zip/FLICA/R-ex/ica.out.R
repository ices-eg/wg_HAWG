### Name: FLICA.out
### Title: Document an FLICA stock assessment
### Aliases: FLICA.out ica.out
### Keywords: classes

### ** Examples

   #Load assessment objects
   data(herIIIa)
   data(herIIIa.tun)
   data(herIIIa.ctrl)
   #Perform assessment
   herIIIa.ica  <- FLICA(herIIIa, herIIIa.tun, herIIIa.ctrl)
   herIIIa <- herIIIa + herIIIa.ica
   #Document assessment with FLICA.out
   options("width"=80)
   icaout <- FLICA.out(herIIIa, herIIIa.tun, herIIIa.ica, format="TABLE 3.1.%i. WBSS HERRING.")
   #Write to file
   write(icaout,file="WBSS Herring ica.out")



