### Name: is.FLAssess.retro
### Title: is.FLAssess.retro
### Aliases: is.FLAssess.retro
### Keywords: classes manip

### ** Examples
## Not run: 
##D     is.FLAssess.retro(new('FLAssess.retro'))
## End(Not run)



