### Name: FLBRP
### Title: Method FLBRP
### Aliases: FLBRP
### Keywords: methods

### ** Examples

# create an FLBRP from ple4 and some extra arguments
fbrp <- FLBRP(ple4, name='Example FLBRP from ple4')
summary(fbrp)



