### Name: FLash
### Title: Automatic Differentiation Based Tools
### Aliases: FLash
### Keywords: fwd fwdTarget

### ** Examples

## Not run: data(ple4) 
##D 
##D target<-fwdTarget(list(year=1998:2000,value=.4,quantity="f"))
##D res   <-fwd(ple4, target, sr.model="mean", sr.param=25000)
##D 
##D fbar(ple4)[,as.character(1995:2000)]
##D fbar(res)[ ,as.character(1995:2000)]
##D 
##D # relative option by setting F to 1, 0.5, 0.1 times that in 1995
##D target[,"value"]<-c(1,.5,.1)
##D target[,"rel"]  <-1995
##D res             <-fwd(ple4, target, sr.model="mean", sr.param=25000)
##D 
##D fbar(res)[ ,as.character(c(1995,1998:2000))]
##D 
##D ## Test for Catch
##D target<-fwdTarget(list(year    =1998:2000,value=c(10000,20000,30000),
##D                        quantity="catch"))
##D res    <-fwd(ple4, target, sr.model="mean", sr.param=25000)
##D 
##D computeCatch(res)[ ,as.character(1995:2000)]
##D 
##D ## Test for SSB
##D # SSB targets are at end of year if harvest.spwn =0.0, otherwise in year
##D target<-fwdTarget(list(year=1998:2000,value=c(200000,210000,220000),quantity="ssb"))
##D 
##D res    <-fwd(ple4, target, sr.model="mean", sr.param=25000)
##D ssb(res)[ ,as.character(1995:2000)]
##D 
##D ## Test for mixed targets
##D target<-fwdTarget(list(year    =rep(1995:2000),value=c(.40,100000,5000,120000,220000,0.65),
##D                        quantity=c("f", "ssb","catch","ssb","ssb","f")))
##D 
##D res    <-fwd(ple4, target, sr.model="mean", sr.param=25000)
##D 
##D #However if a HCR has to set the F next year depending on the biomass midway through
##D # next year that's a bit more difficult.
##D 
##D ## The HCR will set F in 2003 depending on SSB in 2003
##D ## Assessment upto and including 2001
##D black.bird               <-stf(ple4,nyrs=2)
##D 
##D # set courtship and egg laying in Autumn
##D black.bird@m.spwn[]      <-0.66
##D black.bird@harvest.spwn[]<-0.66
##D 
##D # assessment is in year 2002, set catch constraint in 2002 and a first guess for F in 2003
##D target        <-fwdTarget(year=2002:2003,value=c(85000,.5),quantity=c("catch","f"))
##D #target        <-fwdTarget(year=2001:2003,value=c(c(fbar(black.bird)[,"2001"]),85000,.5),quantity=c("f","catch","f"))
##D black.bird    <-fwd.(black.bird, target, sr.model="mean", sr.param=25000)
##D 
##D # HCR specifies F=0.1 if ssb<100000, F=0.5 if ssb>300000
##D # otherwise linear increase as SSB increases
##D min.ssb<-100000
##D max.ssb<-300000
##D min.f  <-0.1
##D max.f  <-0.5
##D 
##D # slope of HCR
##D a.    <-(max.f-min.f)/(max.ssb-min.ssb)
##D b.    <-min.f-a.*min.ssb
##D 
##D # plot of HCR
##D plot(c(0.0,min.ssb,max.ssb,max.ssb*2),c(min.f,min.f,max.f,max.f),type="l",ylim=c(0,max.f*1.25),xlim=c(0,max.ssb*2))
##D 
##D ## find F through iteration
##D t.    <-999
##D i     <-0
##D while (abs(target[2,"value"]-t.)>10e-6 & i<50)
##D    {
##D    t.<-target[2,"value"]  ## save last value of F
##D 
##D    # calculate new F based on SSB last iter
##D    target[2,"value"]<-a.*c(ssb(black.bird)[,"2003"])+b.
##D    black.bird<-fwd(black.bird, target, sr.model="mean", sr.param=25000)
##D 
##D    # 'av a gander
##D    points(c(ssb(black.bird)[,"2003"]),c(target[2,"value"]),cex=1.25,pch=19,col=i)
##D    print(c(ssb(black.bird)[,"2003"]))
##D    print(c(target[2,"value"]))
##D    i<-i+1
##D    }
##D 
##D # F bounds
##D target[,"value"]<-min(max(target[,"value"],.1),.5)
##D black.bird      <-fwd(ple4, target, sr.model="mean", sr.param=25000)
## End(Not run)


