### Name: fwd
### Title: fwd() A generic method for forward projection within FLR
### Aliases: fwd
### Keywords: fwd fwdTarget fwdControl

### ** Examples

## Not run: 
##D target<-fwdTarget(year=2000,value=c(.40,100000,5000,120000,220000,0.65),
##D      quantity=c("f", "ssb","catch","ssb","ssb","f"))
##D codoid.MP  <-fwd(codoid.MP, target, sr.model="mean", sr.param=25000)
## End(Not run)


